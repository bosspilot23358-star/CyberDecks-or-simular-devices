# -*- coding: utf-8 -*-
"""
Параметрический кожух для ASUS GeForce GTX 550 Ti ENGTX550 Ti/DI/1GD5 (215 x 114 x 41 мм, 2 слота).
Стиль: современный «mini»-кожух в духе RTX 50 — плоская лицевая панель
с фаской, крупное отверстие под вентилятор с конической кромкой,
диагональные ламели продува за вентилятором, гравировка на верхнем торце.

Система координат (она же ориентация печати):
  x — вдоль карты, 0 = край со стороны планки (I/O bracket)
  y — поперёк, 0 = верхний край карты (виден в окне корпуса), W = сторона PCIe
  (система правая: если смотреть на вентилятор, PCIe-контакты внизу —
   планка слева)
  z — от лицевой панели (z = 0 лежит на столе принтера) к плате видеокарты
Все размеры в миллиметрах.

Запуск:  python3 make_shroud.py            -> STL + превью + шаблон 1:1
         python3 make_shroud.py --fast     -> грубая сетка, быстро проверить
Нужны: numpy, scipy, scikit-image, matplotlib, pillow.
"""
import sys, math, struct, os
import numpy as np
from scipy import ndimage
from skimage import measure
from PIL import Image, ImageDraw, ImageFont

# ============================ ПАРАМЕТРЫ =====================================
# --- габарит кожуха (ПРОВЕРЬ ЛИНЕЙКОЙ по старому кожуху) ---
L        = 208.0   # длина кожуха по x (карта 215 мм вместе с планкой) — влезает на стол 220
W        = 104.0   # ширина кожуха по y
R_CORNER = 8.0     # радиус скругления углов в плане
CHAMFER  = 2.0     # фаска 45° по периметру лицевой панели
T_PLATE  = 2.4     # толщина лицевой панели
T_WALL   = 2.0     # толщина боковых стенок

# --- вентилятор (по умолчанию стандартный 92 мм, крепёж 82.5 мм) ---
#     для 80 мм: FAN_HOLE_D = 77, FAN_SCREW = 71.5
FAN_CX, FAN_CY = 85.0, W / 2   # центр вентилятора над GPU — ЗАМЕРЬ от края у планки
FAN_HOLE_D  = 89.0   # диаметр окна под крыльчатку
FAN_BEVEL   = 1.6    # коническая кромка окна (на лицевой стороне)
FAN_SCREW   = 82.5   # межосевое расстояние отверстий вентилятора
FAN_T       = 15.0   # толщина вентилятора (92x15 slim; для 92x25 поставь 25)
BOSS_D      = 8.0    # бобышки под крепление вентилятора
BOSS_H      = 3.6    # высота бобышки под панелью (= зазор над вентилятором)
INSERT_D    = 4.0    # отверстие под термовставку M3 (OD ~4.2). Для саморезов 2.6
INSERT_SKIN = 1.2    # «глухая» стенка над вставкой — снаружи винтов не видно

# --- глубина кожуха и крепление к радиатору ---
H        = T_PLATE + BOSS_H + FAN_T + 0.5   # зона вентилятора: от лица до верха радиатора
# --- двухслотовая юбка: стенки опускаются почти до платы и закрывают радиатор ---
FACE_TO_PCB = 36.0   # карта 41 мм (2 слота) минус плата и пайка снизу — ЗАМЕРЬ
SKIRT_DEPTH = FACE_TO_PCB - 2.0   # низ юбки не доходит до платы на 2 мм
VENT_W, VENT_PITCH = 2.4, 5.0     # вертикальные щели выдува радиатора в нижней части юбки
VENT_Z0 = H + 2.0                 # щели начинаются ниже зоны вентилятора...
VENT_Z1 = SKIRT_DEPTH - 2.0       # ...и заканчиваются над низом юбки
FRONT_WALL_Z = H                  # торец у планки — только до радиатора (там DVI/HDMI/DP)
VENT_END_MARGIN = 14.0            # без щелей у углов
# вырез под 6-pin питания на верхней стенке: (x0, x1, высота от низа юбки)
PWR_NOTCH = (L - 36.0, L - 10.0, 17.0)
# Точки крепления к радиатору / старым отверстиям (x, y). ЗАМЕРЬ на старом
# кожухе и подставь. Пустой список = без ножек (крепление стяжками).
MOUNTS   = [(14.0, 14.0), (14.0, W - 14.0), (L - 14.0, 14.0), (L - 14.0, W - 14.0)]
MOUNT_D       = 7.0    # диаметр ножки
MOUNT_HOLE_D  = 2.7    # сквозное под винт M2.5 (под M2 — 2.3, M3 — 3.3)
MOUNT_SINK_D  = 5.4    # диаметр потая на лицевой стороне (90°)
MOUNT_LEN     = H      # длина ножки от лица (до опорной поверхности радиатора)

# --- юбка ---
# Юбка закрывает только зону вентилятора (радиатор с радиальными рёбрами
# остаётся открыт ниже), поэтому по умолчанию она сплошная.
SKIRT_WINDOWS = False
DUCT_WALL  = True     # перегородка за вентилятором: воздух не уходит в ламели
CABLE_SLOT = (6.0, 5.0)   # вырез под провод вентилятора в перегородке (ш x в)
FACE_LINE  = True     # тонкая канавка по периметру лица
BAND = {"top": 11.0, "bottom": 6.0, "front": 6.0, "rear": 6.0}  # высота пояса
POST_W = 5.0          # ширина стоек между окнами
POSTS_LONG = 4        # стоек на длинной стороне (без угловых)
POSTS_END  = 1        # стоек на торце

# --- декор ---
SLOT_ANGLE  = 60.0    # угол диагональных ламелей, град
SLOT_W      = 3.0     # ширина щели ламели
SLOT_PITCH  = 6.5     # шаг ламелей
REAR_MARGIN = 8.0     # поля зоны ламелей
GROOVE_D    = 0.6     # глубина декоративных канавок/гравировки
TEXT        = "GEFORCE GTX"   # гравировка на верхнем торце ("" — без текста)
TEXT_H      = 6.0     # высота заглавных букв
FONT        = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"

RES = 0.25            # шаг сетки, мм (меньше = глаже и тяжелее STL)
# ============================================================================

FAST = "--fast" in sys.argv
if FAST:
    RES = 0.6
OUT = os.path.dirname(os.path.abspath(__file__))


def sd_round_rect(x, y, cx, cy, hx, hy, r):
    qx = np.abs(x - cx) - (hx - r)
    qy = np.abs(y - cy) - (hy - r)
    return (np.hypot(np.maximum(qx, 0), np.maximum(qy, 0))
            + np.minimum(np.maximum(qx, qy), 0) - r)


def sd_box2(x, y, x0, x1, y0, y1):
    return sd_round_rect(x, y, (x0 + x1) / 2, (y0 + y1) / 2,
                         (x1 - x0) / 2, (y1 - y0) / 2, 0.0)


# ---------------------------------------------------------------- 2D поля
pad = 1.5
xs = np.arange(-pad, L + pad, RES)
ys = np.arange(-pad, W + pad, RES)
zs = np.arange(-pad, max(SKIRT_DEPTH, MOUNT_LEN) + pad, RES)
X, Y = np.meshgrid(xs, ys, indexing="ij")

d_out2 = sd_round_rect(X, Y, L / 2, W / 2, L / 2, W / 2, R_CORNER)
d_in2 = d_out2 + T_WALL
rho = np.hypot(X - FAN_CX, Y - FAN_CY)
r_fan = FAN_HOLE_D / 2

mount_dist = [np.hypot(X - mx, Y - my) for (mx, my) in MOUNTS]
mount_keep = np.full_like(X, 1e9)
for d in mount_dist:
    mount_keep = np.minimum(mount_keep, d - MOUNT_D / 2 - 1.5)

# ламели за вентилятором
fan_edge = FAN_CX + FAN_SCREW / 2 + BOSS_D / 2 + 3.0
a = math.radians(SLOT_ANGLE)
u = X * math.cos(a) + Y * math.sin(a)
d_slots = np.abs(np.mod(u, SLOT_PITCH) - SLOT_PITCH / 2) - SLOT_W / 2
region = sd_round_rect(X, Y, (fan_edge + L - REAR_MARGIN) / 2, W / 2,
                       (L - REAR_MARGIN - fan_edge) / 2, W / 2 - REAR_MARGIN, 3.0)
louver2 = np.maximum.reduce([d_slots, region, -(mount_keep - 1.5)])
# убираем мелкие обрезки щелей (< 25 мм2) — они плохо печатаются
lab, nlab = ndimage.label(louver2 < 0)
areas = ndimage.sum(np.ones_like(lab), lab, index=np.arange(1, nlab + 1)) * RES * RES
for i, a_ in enumerate(areas):
    if a_ < 45.0:
        louver2[lab == i + 1] = RES
# и тонкие обрезки (ширина < 1.6 мм) — их не напечатать
_edt = ndimage.distance_transform_edt(louver2 < 0) * RES
_wmax = ndimage.maximum(_edt, lab, index=np.arange(1, lab.max() + 1))
for i, w_ in enumerate(_wmax):
    if w_ < 0.8:
        louver2[lab == i + 1] = RES

# декоративные диагональные канавки у планки (3 линии в том же угле)
front_x1 = FAN_CX - FAN_SCREW / 2 - BOSS_D / 2 - 3.0
g_lines = np.abs(np.mod(u, 4.0) - 2.0) - 0.6
g_region = sd_round_rect(X, Y, (6 + front_x1) / 2, W / 2,
                         max((front_x1 - 6) / 2, 1), W / 2 - 10, 2.0)
groove2 = np.maximum.reduce([g_lines, g_region, -mount_keep])
if FACE_LINE:
    line = np.abs(d_out2 + CHAMFER + 1.8) - 0.4
    groove2 = np.minimum(groove2, np.maximum(line, -mount_keep))

# перегородка за вентилятором
duct_x0 = FAN_CX + FAN_SCREW / 2 + 5.5
duct2 = np.maximum(sd_box2(X, Y, duct_x0, duct_x0 + 1.6, -5, W + 5), d_out2 + 0.5)
cable2 = sd_box2(X, Y, duct_x0 - 1, duct_x0 + 3, W - 14 - CABLE_SLOT[0], W - 14)  # у стороны PCIe

# бобышки вентилятора
fan_pts = [(FAN_CX + sx * FAN_SCREW / 2, FAN_CY + sy * FAN_SCREW / 2)
           for sx in (-1, 1) for sy in (-1, 1)]
boss2 = np.full_like(X, 1e9); bossh2 = np.full_like(X, 1e9)
for (px, py) in fan_pts:
    dd = np.hypot(X - px, Y - py)
    boss2 = np.minimum(boss2, dd - BOSS_D / 2)
    bossh2 = np.minimum(bossh2, dd - INSERT_D / 2)
# соединяем бобышку со стенкой, если она рядом
for (px, py) in fan_pts:
    wy = 0 if py < W / 2 else W
    rib = sd_box2(X, Y, px - BOSS_D / 2 + 1, px + BOSS_D / 2 - 1,
                  min(py, wy + (T_WALL if wy == 0 else -T_WALL)),
                  max(py, wy + (T_WALL if wy == 0 else -T_WALL)))
    boss2 = np.minimum(boss2, np.maximum(rib, d_out2))


# окна юбки (прямоугольники, режущие только стенку)
def spans(total, corner, n_posts):
    if n_posts < 0:
        return []
    a0, a1 = corner, total - corner
    edges = np.linspace(a0, a1, n_posts + 2)
    out = []
    for i in range(len(edges) - 1):
        s0 = edges[i] + (POST_W / 2 if i > 0 else 0)
        s1 = edges[i + 1] - (POST_W / 2 if i < len(edges) - 2 else 0)
        if s1 - s0 > 3:
            out.append((s0, s1))
    return out

c_off = R_CORNER + POST_W / 2
windows = []  # (sdf2d, band)
if not SKIRT_WINDOWS:
    POSTS_LONG = POSTS_END = -100
cut = T_WALL + 1.0
for s0, s1 in spans(L, c_off, POSTS_LONG):
    windows.append((sd_box2(X, Y, s0, s1, -pad - 1, cut), BAND["top"]))
    windows.append((sd_box2(X, Y, s0, s1, W - cut, W + pad + 1), BAND["bottom"]))
for s0, s1 in spans(W, c_off, POSTS_END):
    windows.append((sd_box2(X, Y, -pad - 1, cut, s0, s1), BAND["front"]))
    windows.append((sd_box2(X, Y, L - cut, L + pad + 1, s0, s1), BAND["rear"]))

# не прорезаем окна там, где стоят ножки/бобышки
keep2 = boss2.copy()
for d in mount_dist:
    keep2 = np.minimum(keep2, d - MOUNT_D / 2 - 1)

# ---------------------------------------------------------------- текст
if TEXT:
    ppm = 24  # пикселей на мм
    font = ImageFont.truetype(FONT, int(TEXT_H * ppm * 1.38))
    bbox = font.getbbox(TEXT)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    img = Image.new("L", (tw + 40, th + 40), 0)
    ImageDraw.Draw(img).text((20 - bbox[0], 20 - bbox[1]), TEXT, font=font, fill=255)
    m = np.array(img) > 127
    sd_px = (ndimage.distance_transform_edt(~m) - ndimage.distance_transform_edt(m))
    text_sdf_img = sd_px / ppm
    t_w_mm, t_h_mm = m.shape[1] / ppm, m.shape[0] / ppm
    real_h = th / ppm
    band_top = BAND["top"]
    TXC = L / 2
    TZC = (CHAMFER + (band_top if SKIRT_WINDOWS else H)) / 2   # текст в верхнем поясе
    print(f"текст: {tw/ppm:.1f} x {real_h:.1f} мм")

    def text_field(xv, zv):
        # зритель смотрит на верхний торец (y=0) из окна: право = +x, верх = +z
        uu = (xv - TXC) + t_w_mm / 2          # мм от левого края картинки
        vv = (zv - TZC)                        # мм вверх от центра
        col = uu * ppm
        row = (t_h_mm / 2 - vv) * ppm
        return ndimage.map_coordinates(text_sdf_img, [row, col], order=1,
                                       mode="constant", cval=5.0)

# вертикальные щели в стенках (2D: где режем стенку)
vx = np.abs(np.mod(X - VENT_END_MARGIN, VENT_PITCH) - VENT_PITCH / 2) - VENT_W / 2
vy = np.abs(np.mod(Y - VENT_END_MARGIN, VENT_PITCH) - VENT_PITCH / 2) - VENT_W / 2
in_x = np.maximum(VENT_END_MARGIN - X, X - (L - VENT_END_MARGIN))
in_y = np.maximum(VENT_END_MARGIN - Y, Y - (W - VENT_END_MARGIN))
wall_long = np.minimum(Y - (T_WALL + 1), (W - T_WALL - 1) - Y)  # <0 в длинных стенках
wall_end = np.minimum(X - (T_WALL + 1), (L - T_WALL - 1) - X)
vents2 = np.minimum(np.maximum.reduce([vx, in_x, wall_long]),
                    np.maximum.reduce([vy, in_y, wall_end]))
vents2 = np.maximum(vents2, -keep2)
notch2 = sd_box2(X, Y, PWR_NOTCH[0], PWR_NOTCH[1], -pad - 1, T_WALL + 1.0)

# ---------------------------------------------------------------- 3D
print(f"сетка {len(xs)}x{len(ys)}x{len(zs)}, шаг {RES} мм")
vol = np.empty((len(xs), len(ys), len(zs)), dtype=np.float32)
top_strip = Y[0, :] < 3  # только у верхней стенки считаем текст
for k, z in enumerate(zs):
    d_outer = np.maximum.reduce([d_out2 + max(CHAMFER - z, 0.0),
                                 np.full_like(X, -z), np.full_like(X, z - SKIRT_DEPTH)])
    cavity = np.maximum(d_in2, T_PLATE - z)
    s = np.maximum(d_outer, -cavity)
    # бобышки
    s = np.minimum(s, np.maximum.reduce([boss2, np.full_like(X, z - (T_PLATE + BOSS_H)),
                                         np.full_like(X, T_PLATE - 0.5 - z)]))
    # ножки
    for d in mount_dist:
        s = np.minimum(s, np.maximum.reduce([d - MOUNT_D / 2,
                                             np.full_like(X, z - MOUNT_LEN),
                                             np.full_like(X, T_PLATE - 0.5 - z)]))
    # перегородка с вырезом под кабель
    if DUCT_WALL:
        dw = np.maximum.reduce([duct2, np.full_like(X, z - H), np.full_like(X, T_PLATE - 0.5 - z)])
        dw = np.maximum(dw, -np.maximum(cable2, np.full_like(X, H - CABLE_SLOT[1] - z)))
        s = np.minimum(s, dw)
    # окно вентилятора с конусом
    hole = np.maximum(rho - r_fan - max(FAN_BEVEL - z, 0.0), z - T_PLATE - 0.5)
    s = np.maximum(s, -hole)
    # ламели
    s = np.maximum(s, -np.maximum(louver2, z - T_PLATE - 0.5))
    # канавки
    s = np.maximum(s, -np.maximum(groove2, z - GROOVE_D))
    # отверстия под вставки (глухие)
    s = np.maximum(s, -np.maximum(bossh2, INSERT_SKIN - z))
    # отверстия ножек + потай
    for d in mount_dist:
        h = np.minimum(d - MOUNT_HOLE_D / 2, d - (MOUNT_SINK_D / 2 - z))
        s = np.maximum(s, -h)
    # окна юбки
    for w2, band in windows:
        win = np.maximum.reduce([w2, np.full_like(X, band - z), -keep2])
        s = np.maximum(s, -win)
    # торец у планки открыт ниже зоны вентилятора
    s = np.maximum(s, -np.maximum(sd_box2(X, Y, -pad - 1, T_WALL + 1.0, -pad - 1, W + pad + 1),
                                  np.full_like(X, FRONT_WALL_Z - z)))
    # щели выдува и вырез под питание
    s = np.maximum(s, -np.maximum.reduce([vents2, np.full_like(X, VENT_Z0 - z), np.full_like(X, z - VENT_Z1)]))
    s = np.maximum(s, -np.maximum(notch2, (SKIRT_DEPTH - PWR_NOTCH[2]) - z))
    # гравировка
    if TEXT:
        tf = text_field(X[:, top_strip], np.full(X[:, top_strip].shape, z))
        eng = np.maximum(tf, Y[:, top_strip] - GROOVE_D)
        s[:, top_strip] = np.maximum(s[:, top_strip], -eng)
    vol[:, :, k] = s

vol[np.abs(vol) < 1e-4] = -1e-4  # точные нули на границах областей дают щели-артефакты
np.save(os.path.join(OUT, "vol_%s.npy" % ("fast" if FAST else "full")), vol)
np.save(os.path.join(OUT, "grid_%s.npy" % ("fast" if FAST else "full")), np.array([xs[0], ys[0], zs[0], RES]))
print("marching cubes...")
verts, faces, _, _ = measure.marching_cubes(vol, 0.0, spacing=(RES, RES, RES))
verts += np.array([xs[0], ys[0], zs[0]])
# ориентация нормалей наружу
tri = verts[faces]
vol6 = np.einsum("ij,ij->i", tri[:, 0], np.cross(tri[:, 1], tri[:, 2])).sum()
if vol6 < 0:
    faces = faces[:, ::-1]; tri = verts[faces]; vol6 = -vol6
print(f"треугольников: {len(faces):,}, объём {vol6/6/1000:.1f} см3")


def write_stl(path, tri):
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    n /= (np.linalg.norm(n, axis=1, keepdims=True) + 1e-12)
    rec = np.zeros(len(tri), dtype=[("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
    rec["n"] = n; rec["v"] = tri
    with open(path, "wb") as f:
        f.write(b"ASUS GTX550Ti shroud".ljust(80, b" "))
        f.write(struct.pack("<I", len(tri)))
        f.write(rec.tobytes())

name = "shroud_gtx550ti" + ("_preview" if FAST else "")
write_stl(os.path.join(OUT, name + ".stl"), tri.astype(np.float32))
np.savez_compressed(os.path.join(OUT, name + "_mesh.npz"), v=verts.astype(np.float32), f=faces)
print("готово:", name + ".stl")
