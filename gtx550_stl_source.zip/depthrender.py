import sys, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
tag, out = sys.argv[1], sys.argv[2]
vol = np.load(f"vol_{tag}.npy"); x0, y0, z0, h = np.load(f"grid_{tag}.npy")
solid = vol < 0

def view(axis, from_high, flipx=False, flipy=False, light=(-0.5, -0.6, 0.62)):
    s = np.moveaxis(solid, axis, -1)
    if from_high: s = s[..., ::-1]
    hit = s.any(-1)
    depth = np.where(hit, s.argmax(-1), s.shape[-1]).astype(float) * h
    gy, gx = np.gradient(depth, h)
    n = np.stack([-gx, -gy, np.ones_like(gx)], -1)
    n /= np.linalg.norm(n, axis=-1, keepdims=True)
    L = np.array(light); L /= np.linalg.norm(L)
    shade = np.clip(n @ L, 0, 1) * 0.7 + 0.25 - depth / depth[hit].max() * 0.25 * 0
    img = np.where(hit, shade, np.nan)
    img = img.T[::-1]  # rows = second axis up
    if flipx: img = img[:, ::-1]
    if flipy: img = img[::-1]
    return img

fig, axs = plt.subplots(3, 1, figsize=(12, 15.5), facecolor="#16181c",
                        gridspec_kw=dict(height_ratios=[104, 104, 30]))
cm = plt.get_cmap("gray").copy(); cm.set_bad("#16181c")
# лицевая сторона: смотрим снизу (со стороны z<0) — зеркалим x
def face(from_high):
    s = solid[..., ::-1] if from_high else solid
    hit = s.any(-1); depth = np.where(hit, s.argmax(-1), s.shape[-1]).astype(float) * h
    gx, gy = np.gradient(depth, h)
    n = np.stack([-gx, -gy, np.ones_like(gx)], -1); n /= np.linalg.norm(n, axis=-1, keepdims=True)
    Lv = np.array([-0.45, -0.55, 0.7]); Lv /= np.linalg.norm(Lv)
    im = np.where(hit, np.clip(n @ Lv, 0, 1) * 0.7 + 0.25, np.nan).T  # rows=y (0 сверху), cols=x
    return im[:, ::-1] if from_high else im
ims = [("Лицевая сторона: вентилятор к тебе, PCIe внизу, планка слева", face(False)),
       ("Изнанка (сторона радиатора), планка справа", face(True)),
       ("Верхний торец (вид из окна корпуса; лицо внизу, планка слева)", None)]
# торец: смотрим с +y, право = -x, верх = +z
s = solid  # смотрим со стороны y=0
hit = s.any(1); depth = np.where(hit, s.argmax(1), s.shape[1]).astype(float) * h
gx, gz = np.gradient(depth, h)
n = np.stack([-gx, -gz, np.ones_like(gx)], -1); n /= np.linalg.norm(n, axis=-1, keepdims=True)
Lv = np.array([0.3, 0.7, 0.65]); Lv /= np.linalg.norm(Lv)
side = np.where(hit, np.clip(n @ Lv, 0, 1) * 0.7 + 0.25, np.nan)  # [x, z]
side = side.T[::-1]  # rows z вверх, cols право = +x
ims[2] = (ims[2][0], side)
for ax, (t, im) in zip(axs, ims):
    ax.imshow(im, cmap=cm, vmin=0, vmax=1, interpolation="bilinear")
    ax.set_title(t, color="w", fontsize=13); ax.axis("off")
plt.tight_layout(); plt.savefig(out, dpi=100, facecolor=fig.get_facecolor())
