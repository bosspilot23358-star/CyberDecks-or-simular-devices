import sys, numpy as np, zipfile
def export(npz, out, name):
    d = np.load(npz); v, f = d["v"], d["f"]; v = v - v.min(0)
    vs = "\n".join(f'<vertex x="{a:.3f}" y="{b:.3f}" z="{c:.3f}"/>' for a, b, c in v)
    ts = "\n".join(f'<triangle v1="{a}" v2="{b}" v3="{c}"/>' for a, b, c in f)
    model = (f'<?xml version="1.0" encoding="UTF-8"?>\n<model unit="millimeter" xml:lang="en-US" '
             f'xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><resources><object id="1" type="model" name="{name}">'
             f'<mesh><vertices>\n{vs}\n</vertices><triangles>\n{ts}\n</triangles></mesh></object></resources><build><item objectid="1"/></build></model>')
    ct = '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>'
    rels = '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr("[Content_Types].xml", ct); z.writestr("_rels/.rels", rels); z.writestr("3D/3dmodel.model", model)
if __name__ == "__main__":
    export("shroud_gtx1060_ocv1_mesh.npz", "shroud_gtx1060_ocv1.3mf", "shroud_gtx1060_ocv1")
    export("backplate_gtx1060_ocv1_mesh.npz", "backplate_gtx1060_ocv1.3mf", "backplate_gtx1060_ocv1")
