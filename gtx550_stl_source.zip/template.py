# Шаблон 1:1 (A4 альбом): контур кожуха, отверстия — вид со стороны вентилятора
import importlib.util, sys, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, Rectangle
src = open("make_shroud_550ti.py").read().split("# ============================================================================")[0]
P = {"np": np, "math": __import__("math")}; exec(src.split('"""', 2)[2], P)
L, W = P["L"], P["W"]
mm = 1 / 25.4
fig = plt.figure(figsize=(297 * mm, 210 * mm))
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 297); ax.set_ylim(210, 0); ax.axis("off")
ox, oy = (297 - L) / 2, 30
ax.add_patch(FancyBboxPatch((ox + P["R_CORNER"], oy + P["R_CORNER"]), L - 2 * P["R_CORNER"], W - 2 * P["R_CORNER"],
             boxstyle=f"round,pad={P['R_CORNER']}", fill=False, lw=0.6))
ax.add_patch(Circle((ox + P["FAN_CX"], oy + P["FAN_CY"]), P["FAN_HOLE_D"] / 2, fill=False, lw=0.5, ls="--"))
ax.plot(ox + P["FAN_CX"], oy + P["FAN_CY"], "k+", ms=10, mew=0.5)
for sx in (-1, 1):
    for sy in (-1, 1):
        ax.add_patch(Circle((ox + P["FAN_CX"] + sx * P["FAN_SCREW"] / 2, oy + P["FAN_CY"] + sy * P["FAN_SCREW"] / 2), 2, fill=False, lw=0.5))
for (mx, my) in P["MOUNTS"]:
    cx, cy = ox + mx, oy + my
    ax.add_patch(Circle((cx, cy), P["MOUNT_HOLE_D"] / 2, fill=False, lw=0.6, color="r"))
    ax.plot([cx - 4, cx + 4], [cy, cy], "r-", lw=0.3); ax.plot([cx, cx], [cy - 4, cy + 4], "r-", lw=0.3)
    ax.text(cx, cy + 6.5, f"({mx:.0f}; {my:.0f})", ha="center", fontsize=6, color="r")
dx = ox + P["FAN_CX"] + P["FAN_SCREW"] / 2 + 5.5
ax.add_patch(Rectangle((dx, oy), 1.6, W, fill=False, lw=0.3, ls=":"))
ax.annotate("", (ox, oy - 4), (ox + L, oy - 4), arrowprops=dict(arrowstyle="<->", lw=0.4))
ax.text(ox + L / 2, oy - 5.5, f"{L:.0f} мм", ha="center", fontsize=7)
ax.text(ox - 3, oy + W / 2, f"{W:.0f} мм", ha="right", va="center", fontsize=7, rotation=90)
ax.text(ox, oy + W + 6, "◄ ПЛАНКА (I/O)", fontsize=7)
ax.text(ox + L / 2, oy + W + 6, "сторона PCIe-разъёма", ha="center", fontsize=7)
ax.text(ox + L / 2, oy - 11, "верхний край карты (виден в окне)", ha="center", fontsize=7)
ax.text(ox, 8, "Шаблон кожуха ASUS GTX 550 Ti ENGTX550 Ti/DI/1GD5 — масштаб 1:1, печатать «100% / без подгонки»", fontsize=9, weight="bold")
ax.text(ox, 13, "Вид со стороны вентилятора (как смотришь на карту, PCIe-контакты внизу). Красное — точки крепления к радиатору,"
        " пунктир — окно вентилятора, кружки — винты вентилятора 92 мм.", fontsize=6.5)
ax.plot([ox, ox + 100], [195, 195], "k-", lw=0.8)
for t in range(0, 101, 10): ax.plot([ox + t, ox + t], [193.5 if t % 50 else 192, 195], "k-", lw=0.5)
ax.text(ox + 102, 195.5, "100 мм — проверь линейкой, что масштаб верный", fontsize=6.5, va="center")
fig.savefig("shroud_gtx550ti_template_1to1_A4.pdf"); fig.savefig("template_check.png", dpi=80)
