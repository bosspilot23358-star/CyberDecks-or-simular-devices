# -*- coding: utf-8 -*-
"""
Radxa ROCK 2F (2 ГБ) + экран MPI3508 3.5" HDMI (480x320, v1.2) с комплектным
U-образным переходником HDMI-HDMI + Xiaomi Mi Power Bank 2 5000 мАч (127 x 68.9 x 10.7)
горизонтально сзади.

Выход:
  rock2f_pb_assembly.3mf   — цветная 3D-сборка (компоненты + корпус) для просмотра
  r2f_body.*               — корпус: окно экрана, решётка, окно USB-A, вход кабеля питания
  r2f_tray.*               — лоток повербанка + крепление ROCK 2F (печать стоя на торце)
  r2f_endplate_holes.*     — торцевая панель: USB-A, micro-USB, кнопка, 4 отверстия индикаторов
  r2f_endplate_open.*      — запасной вариант: одно длинное окно на весь торец банка

Координаты конструктора: x вправо, y вверх (вид спереди), d — глубина от лица назад.
python3 make_rock2f_pb.py [--fast]
"""
import sys, os, math, struct, zipfile
import numpy as np
from skimage import measure

FAST = "--fast" in sys.argv
RES = 0.6 if FAST else 0.25
OUT = os.path.dirname(os.path.abspath(__file__))

# ============================ ПАРАМЕТРЫ =====================================
WALL, T_FRONT, CH_FRONT, R_CORNER = 2.5, 1.6, 1.2, 6.0
# --- повербанк Mi Power Bank 2 5000 (PLM10ZM) ---
PB_L, PB_W, PB_T, PB_CLR = 127.0, 68.9, 10.7, 0.3
END_T = 2.6                                   # толщина торцевой панели
W = PB_L + 2 * PB_CLR + 2.6 + END_T           # ширина корпуса
H = 78.0                                      # высота корпуса
# --- экран MPI3508 (модуль 85.5 x 56, АА 73.44 x 48.96) ---
MOD_W, MOD_H = 85.5, 56.0
MX0, MY0 = WALL + 0.5, WALL + 0.5             # экран прижат к левому нижнему углу
AA_W, AA_H, AA_DX, AA_DY, WIN_M = 73.44, 48.96, 0.0, 0.0, 0.6
T_LCD, STACK_GAP = 4.5, 13.0
D_DPCB = T_FRONT + T_LCD                      # плата экрана: D_DPCB..+1.6
D_RPCB = D_DPCB + 1.6 + STACK_GAP             # лицевая сторона ROCK 2F
# --- ROCK 2F (65 x 56): USB-A смотрят влево, microSD справа, HDMI/USB-C вверху ---
RX0, RX1 = MX0 + MOD_W - 65.0, MX0 + MOD_W
RY0, RY1 = MY0, MY0 + MOD_H
ROCK_HOLES = [(RX1 - v, RY1 - u) for v in (3.5, 61.5) for u in (3.5, 52.5)]
USB_Y = [RY1 - 21.08, RY1 - 39.90]
HDMI_X, USBC_X, SD_Y = RX1 - 31.7, RX1 - 11.2, RY1 - 27.7
# --- корпус / лоток ---
D_BODY = D_RPCB + 1.6 + 2.7                   # передняя плоскость лотка
T_PLATE = 1.6
D_CH0, D_CH1 = D_BODY + T_PLATE, D_BODY + T_PLATE + PB_T + 2 * PB_CLR    # канал банка
D_BACK = D_CH1 + 2.0                          # задняя поверхность
CH_X0, CH_X1 = 2.6, W - END_T                 # канал банка по x (открыт справа)
CH_Y0, CH_Y1 = (H - PB_W) / 2 - PB_CLR, (H + PB_W) / 2 + PB_CLR
SCREWS = [(8.0, 2.1), (118.0, 2.1), (8.0, H - 2.1), (118.0, H - 2.1)]   # корпус ↔ лоток, M2.5
PILOT, CLR_D, SINK = 2.2, 2.8, 5.2
# --- торец банка (центр торца) ---
PB_YC, PB_DC = H / 2, (D_CH0 + D_CH1) / 2
# Раскладка торца Mi Power Bank 2 по ширине (смещение от центра торца, мм). ЗАМЕРЬ!
USBA_DY, USBA = 0.0, (17.0, 9.5)              # окно под штекер USB-A (с корпусом штекера)
MUSB_DY, MUSB = -18.0, (11.0, 7.0)            # micro-USB (зарядка банка)
BTN_DY, BTN_D = 17.0, 6.0                     # кнопка Power Check
LED_DY = [22.5, 25.0, 27.5, 30.0]             # 4 индикатора уровня заряда
LED_D = 1.6
END_SCREWS = [(2.1, PB_DC), (H - 2.1, PB_DC)]  # (y, d) винты торцевой панели вдоль x
CABLE_HOLE = (60.0, 72.0, 6.0, 18.0)          # правая стенка: вход кабеля USB-A→USB-C (y0,y1,d0,d1)
# ============================================================================


def rr(a, b, a0, a1, b0, b1, r):
    ca, cb, ha, hb = (a0 + a1) / 2, (b0 + b1) / 2, (a1 - a0) / 2, (b1 - b0) / 2
    r = min(r, ha, hb)
    qa = np.abs(a - ca) - (ha - r); qb = np.abs(b - cb) - (hb - r)
    return np.hypot(np.maximum(qa, 0), np.maximum(qb, 0)) + np.minimum(np.maximum(qa, qb), 0) - r


def box2(a, b, a0, a1, b0, b1):
    return rr(a, b, a0, a1, b0, b1, 0.0)


def dr(d, d0, d1):
    return max(d0 - d, d - d1)


# ---------------------------------------------------------------- корпус
def body_sdf(X, Y, d, c):
    if "out" not in c:
        c["out"] = rr(X, Y, 0, W, 0, H, R_CORNER)
        c["inn"] = c["out"] + WALL
        cx, cy = MX0 + MOD_W / 2 + AA_DX, MY0 + MOD_H / 2 + AA_DY
        c["win"] = rr(X, Y, cx - AA_W / 2 - WIN_M, cx + AA_W / 2 + WIN_M, cy - AA_H / 2 - WIN_M, cy + AA_H / 2 + WIN_M, 1.0)
        u = X * math.cos(math.radians(60)) + Y * math.sin(math.radians(60))
        slots = np.abs(np.mod(u, 5.5) - 2.75) - 1.25
        c["grille"] = np.maximum(slots, rr(X, Y, MX0 + MOD_W + 6, W - 8, 10, H - 10, 3))
        c["usb"] = rr(X, Y, -5, WALL + 1, min(USB_Y) - 9, max(USB_Y) + 9, 2)
        c["cab"] = box2(X, Y, W - WALL - 1, W + 5, CABLE_HOLE[0], CABLE_HOLE[1])
        blocks = []
        for sx, sy in SCREWS:
            x0, x1 = sx - 4, sx + 4
            y0, y1 = (0, 6.0) if sy < H / 2 else (H - 6.0, H)
            blocks.append(box2(X, Y, x0, x1, y0, y1))
        c["blk"] = blocks
        c["pil"] = np.minimum.reduce([np.hypot(X - sx, Y - sy) - PILOT / 2 for sx, sy in SCREWS])
        c["loc"] = np.minimum.reduce([box2(X, Y, MX0 + 1, MX0 + 7, RY1 + 0.3, RY1 + 2.3),
                                      box2(X, Y, MX0 + MOD_W - 7, MX0 + MOD_W - 1, RY1 + 0.3, RY1 + 2.3),
                                      box2(X, Y, MX0 + MOD_W + 0.3, MX0 + MOD_W + 2.3, MY0 + 8, MY0 + MOD_H - 8)])
        c["line"] = np.abs(c["out"] + CH_FRONT + 1.4) - 0.3
    out = c["out"]
    s = np.maximum.reduce([out + max(CH_FRONT - d, 0.0), np.full_like(X, -d), np.full_like(X, d - D_BODY)])
    s = np.maximum(s, -np.maximum(c["inn"], T_FRONT - d))
    # прямоугольный угол под модуль экрана (внутреннее скругление стенок мешает)
    s = np.maximum(s, -np.maximum(box2(X, Y, MX0 - 0.3, MX0 + MOD_W + 0.3, MY0 - 0.3, MY0 + MOD_H + 0.3), dr(d, T_FRONT, D_DPCB + 1.8)))
    for (sx, sy), b in zip(SCREWS, c["blk"]):
        d0 = D_DPCB + 2.0 if (sx < MX0 + MOD_W and sy < H / 2) else T_FRONT - 0.5   # над экраном — только за ним
        s = np.minimum(s, np.maximum.reduce([b, out, np.full_like(X, dr(d, d0, D_BODY))]))
    s = np.minimum(s, np.maximum(c["loc"], dr(d, T_FRONT - 0.5, T_FRONT + 5.0)))
    s = np.maximum(s, -np.maximum(c["win"] - max(0.8 - d, 0.0), d - T_FRONT - 0.5))
    s = np.maximum(s, -np.maximum(c["grille"], d - T_FRONT - 0.5))
    s = np.maximum(s, -np.maximum(c["usb"], dr(d, D_RPCB - 8.5, D_BODY + 1)))
    s = np.maximum(s, -np.maximum(rr(X, Y, W - WALL - 1, W + 5, *CABLE_HOLE[:2], 2.0), dr(d, CABLE_HOLE[2], CABLE_HOLE[3])))
    s = np.maximum(s, -np.maximum(c["pil"], D_BODY - 12.0 - d))
    s = np.maximum(s, -np.maximum(c["line"], d - 0.4))
    return s


# ---------------------------------------------------------------- лоток
def tray_sdf(X, Y, d, c):
    if "out" not in c:
        c["out"] = rr(X, Y, 0, W, 0, H, R_CORNER)
        c["cut"] = X - CH_X1                                  # справа место под торцевую панель
        c["ch"] = box2(X, Y, CH_X0, W + 5, CH_Y0, CH_Y1)
        c["rb"] = np.minimum.reduce([np.hypot(X - hx, Y - hy) - 3.25 for hx, hy in ROCK_HOLES])
        c["rp"] = np.minimum.reduce([np.hypot(X - hx, Y - hy) - PILOT / 2 for hx, hy in ROCK_HOLES])
        c["sd"] = [np.hypot(X - sx, Y - sy) for sx, sy in SCREWS]
        c["ep"] = [np.hypot(Y - ey, 0) for ey, _ in END_SCREWS]
    out = c["out"]
    s = np.maximum.reduce([out + max(d - (D_BACK - 1.0), 0.0), np.full_like(X, D_BODY - d), np.full_like(X, d - D_BACK), c["cut"]])
    s = np.maximum(s, -np.maximum(c["ch"], dr(d, D_CH0, D_CH1)))
    s = np.minimum(s, np.maximum(c["rb"], dr(d, D_RPCB + 1.7, D_BODY + 0.5)))      # бобышки ROCK 2F
    s = np.maximum(s, -np.maximum(c["rp"], d - (D_BODY + 1.2)))
    for dd in c["sd"]:
        s = np.maximum(s, -np.minimum(dd - CLR_D / 2, dd - (SINK / 2 - (D_BACK - d))))
    # пилоты под винты торцевой панели (вдоль x, в верхней и нижней стенке лотка)
    for (ey, ed) in END_SCREWS:
        r = np.hypot(Y - ey, d - ed)
        s = np.maximum(s, -np.maximum(r - PILOT / 2, (CH_X1 - 8.0) - X))
    return s


# ---------------------------------------------------------------- торцевая панель (срез по x не нужен: строим в (y, d), выдавливаем по x)
def endplate_sdf(x, Y, D, variant):
    s = np.maximum.reduce([rr(np.full_like(Y, x), Y, 0, W, 0, H, R_CORNER),
                           np.maximum(D_BODY - D, D - D_BACK) + np.maximum(D - (D_BACK - 1.0), 0),
                           np.full_like(Y, max(CH_X1 - x, x - W))])
    yc, dc = PB_YC, PB_DC
    if variant == "open":
        s = np.maximum(s, -rr(Y, D, yc - 31, yc + 31, dc - 4.2, dc + 4.2, 2.0))
    else:
        s = np.maximum(s, -rr(Y, D, yc + USBA_DY - USBA[0] / 2, yc + USBA_DY + USBA[0] / 2, dc - USBA[1] / 2, dc + USBA[1] / 2, 1.5))
        s = np.maximum(s, -rr(Y, D, yc + MUSB_DY - MUSB[0] / 2, yc + MUSB_DY + MUSB[0] / 2, dc - MUSB[1] / 2, dc + MUSB[1] / 2, 1.5))
        cham = max(0.0, x - (W - 1.0))                         # фаска снаружи у кнопки
        s = np.maximum(s, -(np.hypot(Y - (yc + BTN_DY), D - dc) - (BTN_D / 2 + cham)))
        for ly in LED_DY:
            s = np.maximum(s, -(np.hypot(Y - (yc + ly), D - dc) - LED_D / 2))
    for (ey, ed) in END_SCREWS:
        r = np.hypot(Y - ey, D - ed)
        s = np.maximum(s, -np.minimum(r - CLR_D / 2, r - (SINK / 2 - (W - x))))
    return s


# ---------------------------------------------------------------- сетки
def mc(vol, origin):
    vol[np.abs(vol) < 1e-4] = -1e-4
    v, f, _, _ = measure.marching_cubes(vol, 0.0, spacing=(RES,) * 3)
    return v + np.array(origin), f


def build_xyd(fn, d0, d1, x0=0, x1=None):
    x1 = W if x1 is None else x1
    xs = np.arange(x0 - 1, x1 + 1, RES); ys = np.arange(-1, H + 1, RES); ds = np.arange(d0 - 1, d1 + 1, RES)
    X, Y = np.meshgrid(xs, ys, indexing="ij"); c = {}
    vol = np.empty((len(xs), len(ys), len(ds)), np.float32)
    for k, d in enumerate(ds):
        vol[:, :, k] = fn(X, Y, float(d), c)
    return mc(vol, (xs[0], ys[0], ds[0]))


def build_endplate(variant):
    xs = np.arange(CH_X1 - 1, W + 1, RES); ys = np.arange(-1, H + 1, RES); ds = np.arange(D_BODY - 1, D_BACK + 1, RES)
    Y, D = np.meshgrid(ys, ds, indexing="ij")
    vol = np.empty((len(xs), len(ys), len(ds)), np.float32)
    for i, x in enumerate(xs):
        vol[i] = endplate_sdf(float(x), Y, D, variant)
    return mc(vol, (xs[0], ys[0], ds[0]))


def phys(v):            # (x, y, d) -> физические (x, y, z = -d): правая система
    return np.stack([v[:, 0], v[:, 1], -v[:, 2]], -1)


def write_stl(name, v, f):
    v = v - v.min(0); tri = v[f]
    if np.einsum("ij,ij->i", tri[:, 0], np.cross(tri[:, 1], tri[:, 2])).sum() < 0:
        f = f[:, ::-1]; tri = v[f]
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]); n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-12
    rec = np.zeros(len(tri), dtype=[("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]); rec["n"] = n; rec["v"] = tri
    with open(os.path.join(OUT, name + ".stl"), "wb") as fh:
        fh.write(name.encode().ljust(80)); fh.write(struct.pack("<I", len(tri))); fh.write(rec.tobytes())
    print(f"{name}: {len(f):,} треуг., габарит {np.round(v.max(0), 1)} мм")
    return v, f


def write_3mf(path, objects):
    """objects: [(name, v, f, '#RRGGBB')] в одних координатах — цветная сборка."""
    mats = "".join(f'<base name="{n}" displaycolor="{col}FF"/>' for n, _, _, col in objects)
    res = [f'<basematerials id="1">{mats}</basematerials>']
    items = []
    for i, (n, v, f, col) in enumerate(objects):
        oid = i + 2
        tri = v[f]
        if np.einsum("ij,ij->i", tri[:, 0], np.cross(tri[:, 1], tri[:, 2])).sum() < 0:
            f = f[:, ::-1]
        vs = "".join(f'<vertex x="{a:.3f}" y="{b:.3f}" z="{c_:.3f}"/>' for a, b, c_ in v)
        ts = "".join(f'<triangle v1="{a}" v2="{b}" v3="{c_}"/>' for a, b, c_ in f)
        res.append(f'<object id="{oid}" type="model" name="{n}" pid="1" pindex="{i}"><mesh><vertices>{vs}</vertices><triangles>{ts}</triangles></mesh></object>')
        items.append(f'<item objectid="{oid}"/>')
    model = ('<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="en-US" '
             'xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><resources>' + "".join(res) +
             '</resources><build>' + "".join(items) + '</build></model>')
    ct = '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>'
    rels = '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr("[Content_Types].xml", ct); z.writestr("_rels/.rels", rels); z.writestr("3D/3dmodel.model", model)


# ---------------------------------------------------------------- компоненты (простые тела)
def boxmesh(x0, x1, y0, y1, d0, d1):
    v = np.array([[x, y, d] for x in (x0, x1) for y in (y0, y1) for d in (d0, d1)], float)
    q = [(0, 2, 3, 1), (4, 5, 7, 6), (0, 1, 5, 4), (2, 6, 7, 3), (0, 4, 6, 2), (1, 3, 7, 5)]
    f = []
    for a, b, c_, e in q:
        f += [(a, b, c_), (a, c_, e)]
    return v, np.array(f)


def merge(parts):
    vs, fs, off = [], [], 0
    for v, f in parts:
        vs.append(v); fs.append(f + off); off += len(v)
    return np.concatenate(vs), np.concatenate(fs)


def components():
    C = {}
    C["ROCK 2F"] = merge([
        boxmesh(RX0, RX1, RY0, RY1, D_RPCB, D_RPCB + 1.6),                                         # плата
        *[boxmesh(RX0 - 4.3, RX0 + 10, uy - 6.6, uy + 6.6, D_RPCB - 7.0, D_RPCB) for uy in USB_Y],  # 2x USB-A
        boxmesh(HDMI_X - 7.5, HDMI_X + 7.5, RY1 - 11, RY1 + 1.5, D_RPCB - 6.5, D_RPCB),           # HDMI
        boxmesh(USBC_X - 4.5, USBC_X + 4.5, RY1 - 7, RY1 + 1, D_RPCB - 3.3, D_RPCB),              # USB-C
        boxmesh(RX1 - 58, RX1 - 7, RY0 + 0.5, RY0 + 5.5, D_RPCB - 8.5, D_RPCB),                   # 40-pin
        boxmesh(RX1 - 40, RX1 - 26, RY1 - 33, RY1 - 19, D_RPCB - 1.2, D_RPCB),                    # SoC
        boxmesh(RX1 - 1.5, RX1 + 1.5, SD_Y - 6, SD_Y + 6, D_RPCB + 1.6, D_RPCB + 3.1),           # microSD
    ])
    cx, cy = MX0 + MOD_W / 2 + AA_DX, MY0 + MOD_H / 2 + AA_DY
    C["MPI3508 (корпус)"] = merge([
        boxmesh(MX0, MX0 + MOD_W, MY0, MY0 + MOD_H, T_FRONT + 0.3, D_DPCB + 1.6),
        boxmesh(HDMI_X - 7.5, HDMI_X + 7.5, RY1 - 1, RY1 + 4.6, D_DPCB + 1.6, D_DPCB + 7.5),     # HDMI экрана
        boxmesh(RX1 - 58, RX1 - 7, RY0 + 0.5, RY0 + 5.5, D_DPCB + 1.6, D_RPCB - 8.5),           # гребёнка 40-pin
    ])
    C["MPI3508 (экран)"] = boxmesh(cx - AA_W / 2, cx + AA_W / 2, cy - AA_H / 2, cy + AA_H / 2, T_FRONT + 0.2, T_FRONT + 0.3)
    C["U-переходник HDMI"] = merge([
        boxmesh(HDMI_X - 11, HDMI_X + 11, RY1 + 4.6, RY1 + 15.5, D_DPCB + 1.0, D_RPCB),
        boxmesh(HDMI_X - 7, HDMI_X + 7, RY1 + 1.5, RY1 + 4.6, D_RPCB - 6.0, D_RPCB - 0.5),
    ])
    px0, px1 = CH_X0 + PB_CLR, CH_X1 - PB_CLR
    py0, py1 = PB_YC - PB_W / 2, PB_YC + PB_W / 2
    pd0, pd1 = PB_DC - PB_T / 2, PB_DC + PB_T / 2
    C["Mi Power Bank 2"] = boxmesh(px0, px1, py0, py1, pd0, pd1)
    marks = [boxmesh(px1 - 0.05, px1 + 0.05, PB_YC + USBA_DY - 6, PB_YC + USBA_DY + 6, PB_DC - 2.3, PB_DC + 2.3),
             boxmesh(px1 - 0.05, px1 + 0.05, PB_YC + MUSB_DY - 4, PB_YC + MUSB_DY + 4, PB_DC - 1.4, PB_DC + 1.4),
             boxmesh(px1 - 0.05, px1 + 0.05, PB_YC + BTN_DY - 2, PB_YC + BTN_DY + 2, PB_DC - 2, PB_DC + 2)]
    marks += [boxmesh(px1 - 0.05, px1 + 0.05, PB_YC + ly - 0.5, PB_YC + ly + 0.5, PB_DC - 0.5, PB_DC + 0.5) for ly in LED_DY]
    C["порты банка"] = merge(marks)
    return C


if __name__ == "__main__":
    sfx = "_fast" if FAST else ""
    print(f"Корпус {W:.1f} x {H:.0f} x {D_BACK:.1f} мм")
    body = build_xyd(body_sdf, 0, D_BODY)
    tray = build_xyd(tray_sdf, D_RPCB, D_BACK)
    ep_h = build_endplate("holes"); ep_o = build_endplate("open")
    np.savez_compressed(os.path.join(OUT, f"parts{sfx}.npz"), bv=body[0], bf=body[1], tv=tray[0], tf=tray[1],
                        hv=ep_h[0], hf=ep_h[1], ov=ep_o[0], of=ep_o[1])
    # печать: корпус лицом вниз — (x, -y, d); лоток стоя на левом торце — (y, -d, x); панель наружной стороной вниз — (-d, y, W - x)
    write_stl(f"r2f_body{sfx}", np.stack([body[0][:, 0], -body[0][:, 1], body[0][:, 2]], -1), body[1])
    write_stl(f"r2f_tray{sfx}", np.stack([tray[0][:, 1], -tray[0][:, 2], tray[0][:, 0]], -1), tray[1])
    for nm, (v, f) in (("holes", ep_h), ("open", ep_o)):
        write_stl(f"r2f_endplate_{nm}{sfx}", np.stack([-v[:, 2], v[:, 1], W - v[:, 0]], -1), f)
    # цветная сборка
    objs = [("Корпус", phys(body[0]), body[1], "#E8E8EC"), ("Лоток повербанка", phys(tray[0]), tray[1], "#B8C4D8"),
            ("Торцевая панель", phys(ep_h[0]), ep_h[1], "#9AA6BC")]
    cols = {"ROCK 2F": "#1E7A3C", "MPI3508 (корпус)": "#2A2D35", "MPI3508 (экран)": "#1B3A8C", "U-переходник HDMI": "#111111",
            "Mi Power Bank 2": "#C9CCD2", "порты банка": "#222222"}
    for n, (v, f) in components().items():
        objs.append((n, phys(v), f, cols[n]))
    write_3mf(os.path.join(OUT, f"rock2f_pb_assembly{sfx}.3mf"), objs)
    print("сборка: rock2f_pb_assembly" + sfx + ".3mf")
