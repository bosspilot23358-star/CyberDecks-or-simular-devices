import sys, numpy as np, importlib.util
spec=importlib.util.spec_from_file_location("m","make_rock2f_pb.py"); M=importlib.util.module_from_spec(spec); sys.argv=["x"]; spec.loader.exec_module(M)
def boxes_of(v,f):
    # компоненты собраны из боксов по 8 вершин подряд
    return [v[i:i+8] for i in range(0,len(v),8)]
comps=M.components()
h=0.4
def pts(b):
    mn,mx=b.min(0),b.max(0)
    g=[np.arange(mn[a]+h/2,mx[a],h) if mx[a]-mn[a]>h else np.array([(mn[a]+mx[a])/2]) for a in range(3)]
    return np.stack(np.meshgrid(*g,indexing="ij"),-1).reshape(-1,3)
def sdf_body(P):
    out=np.full(len(P),1e9)
    for dv in np.unique(np.round(P[:,2]/h)*h):
        m=np.abs(P[:,2]-dv)<h/2+1e-6
        out[m]=M.body_sdf(P[m,0],P[m,1],float(dv),{})
    return out
def sdf_tray(P):
    out=np.full(len(P),1e9)
    for dv in np.unique(np.round(P[:,2]/h)*h):
        m=np.abs(P[:,2]-dv)<h/2+1e-6
        out[m]=M.tray_sdf(P[m,0],P[m,1],float(dv),{})
    return out
def sdf_ep(P):
    out=np.full(len(P),1e9)
    for xv in np.unique(np.round(P[:,0]/h)*h):
        m=np.abs(P[:,0]-xv)<h/2+1e-6
        out[m]=M.endplate_sdf(float(xv),P[m,1],P[m,2],"holes")
    return out
print("Пересечения компонентов с деталями (мм3):")
for name,(v,f) in comps.items():
    if name=="порты банка": continue
    tot={"корпус":0,"лоток":0,"торец":0}
    for b in boxes_of(v,f):
        P=pts(b)
        tot["корпус"]+=(sdf_body(P)<-0.1).sum()*h**3
        tot["лоток"]+=(sdf_tray(P)<-0.1).sum()*h**3
        tot["торец"]+=(sdf_ep(P)<-0.1).sum()*h**3
    bad={k:round(x,1) for k,x in tot.items() if x>0.5}
    print(f"  {name:22s}", "OK" if not bad else bad)
# детали между собой
P=np.stack(np.meshgrid(np.arange(0,M.W,0.5),np.arange(0,M.H,0.5),np.arange(M.D_BODY-1.5,M.D_BACK,0.5),indexing="ij"),-1).reshape(-1,3)
b=sdf_body(P)<-0.1; t=sdf_tray(P)<-0.1; e=sdf_ep(P)<-0.1
print("корпус∩лоток", (b&t).sum()*0.125, " лоток∩торец", (t&e).sum()*0.125, " корпус∩торец", (b&e).sum()*0.125)
# совпадение отверстий торца с портами банка
for nm,dy in (("USB-A",M.USBA_DY),("micro-USB",M.MUSB_DY),("кнопка",M.BTN_DY))+tuple((f"LED{i+1}",l) for i,l in enumerate(M.LED_DY)):
    y=M.PB_YC+dy; print(f"  {nm}: торец открыт = {M.endplate_sdf(M.W-1.3, np.array([y]), np.array([M.PB_DC]), 'holes')[0] > 0}")
