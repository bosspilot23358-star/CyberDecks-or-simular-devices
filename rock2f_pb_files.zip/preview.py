import sys, numpy as np, importlib.util
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
spec=importlib.util.spec_from_file_location("m","make_rock2f_pb.py"); M=importlib.util.module_from_spec(spec); sys.argv=["x"]; spec.loader.exec_module(M)
P=np.load("parts.npz")
def ph(v): return np.stack([v[:,0],v[:,1],-v[:,2]],-1)
parts=[(ph(P["bv"])[P["bf"]],(.92,.92,.94),"body"),(ph(P["tv"])[P["tf"]],(.72,.77,.85),"tray"),(ph(P["hv"])[P["hf"]],(.6,.65,.75),"end")]
cols={"ROCK 2F":(.12,.48,.24),"MPI3508 (корпус)":(.16,.18,.21),"MPI3508 (экран)":(.11,.23,.55),"U-переходник HDMI":(.07,.07,.07),"Mi Power Bank 2":(.79,.8,.82),"порты банка":(.1,.1,.1)}
comps=[]
quads=[(0,2,3,1),(4,5,7,6),(0,1,5,4),(2,6,7,3),(0,4,6,2),(1,3,7,5)]
for n,(v,f) in M.components().items():
    v=ph(v)
    for i in range(0,len(v),8):
        b=v[i:i+8]; comps+= [(b[list(q)],cols[n]) for q in quads]
def draw(ax, views, which, title, explode=0.0):
    el,az=views; e,a=np.radians(el),np.radians(az); cam=np.array([np.cos(e)*np.cos(a),np.cos(e)*np.sin(a),np.sin(e)])
    L=cam+np.array([.3,.5,.8]); L/=np.linalg.norm(L); polys=[]; cs=[]
    for tri,col,nm in parts:
        if nm not in which: continue
        off=np.array([0,0,-explode]) if nm!="body" else np.zeros(3)
        if nm=="end": off=np.array([explode,0,-explode])
        n=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]); n/=np.linalg.norm(n,axis=1,keepdims=True)+1e-9
        sh=np.abs(n@L)*.45+.5
        polys+=list(tri+off); cs+=[tuple(np.array(col)*s) for s in sh]
    if "comp" in which:
        for q,col in comps:
            nn=np.cross(q[1]-q[0],q[2]-q[0]); nn/=np.linalg.norm(nn)+1e-9
            off=np.zeros(3)
            polys.append(q+off); cs.append(tuple(np.clip(np.array(col)*(abs(nn@L)*.5+.6),0,1)))
    cen=np.array([np.mean(p,0)@cam for p in polys]); o=np.argsort(cen)
    ax.add_collection3d(Poly3DCollection([polys[j] for j in o],facecolors=[cs[j] for j in o],edgecolors="none"))
    ax.set_xlim(-5,140); ax.set_ylim(-5,140); ax.set_zlim(-110,35); ax.set_box_aspect((1,1,1)); ax.view_init(el,az); ax.set_axis_off(); ax.set_title(title,fontsize=12)
fig=plt.figure(figsize=(20,7))
draw(fig.add_subplot(1,3,1,projection="3d"),(20,-75),("body","tray","end","comp"),"Спереди: экран 3.5\", решётка, окно USB-A слева")
draw(fig.add_subplot(1,3,2,projection="3d"),(20,30),("body","tray","end","comp"),"Справа-сзади: торец банка — USB, micro-USB, кнопка, индикаторы")
draw(fig.add_subplot(1,3,3,projection="3d"),(25,-50),("comp",),"Внутри: ROCK 2F + MPI3508 + U-HDMI + Mi Power Bank 2")
plt.tight_layout(); plt.savefig("rock2f_pb_preview.png",dpi=85)
